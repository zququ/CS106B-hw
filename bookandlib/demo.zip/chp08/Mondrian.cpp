/*
 * FILE: CANTOR FRACTALS
 * ---------------------
 * This program draws a Cantor Fractal of a constant depth on the screen.
 * A Cantor fractal of depth N is a thick horizontal line on top, with
 * a depth N-1 Cantor fractal below the left third, and a depth N-1 Cantor
 * fractal below the right third, of the drawn line.
 */

#include "gwindow.h"
#include "random.h"
#include <math.h>

using namespace std;

static const double MIN_AREA = 10000;
static const double MIN_EDGE = 20;

void fillColor(GWindow &w, double x, double y, double width, double height){
	w.fillRect(x, y, width, height);
	switch(randomInteger(1, 5)){
	    case 1:
		w.setColor("#fac901");		
		break;
	    case 2:
		w.setColor("#225095");
		break;
	    case 3:
		w.setColor("#dd0100");
		break;
	    default:
		w.setColor("#ffffff");
		break;
	}

	if(x == y) {
	    w.fillRect(x, y, width, height);
	    w.setColor("#ffffff");
	}
}

void subdivideCanvas(GWindow &w, double x, double y, double width, double height) {
    if (width * height < MIN_AREA) {
	fillColor(w, x, y, width, height);
        return;
    }

    if (width > height) {
        double mid = randomReal(MIN_EDGE, width - MIN_EDGE);
        subdivideCanvas(w, x, y, mid, height);
        subdivideCanvas(w, x + mid, y, width - mid, height);
        w.drawLine(x + mid, y, x + mid, y + height);
    } else {
        double mid = randomReal(MIN_EDGE, height - MIN_EDGE);
        subdivideCanvas(w, x, y, width, mid);
        subdivideCanvas(w, x, y + mid, width, height - mid);
        w.drawLine(x, y + mid, x + width, y + mid);
    }
}

int main() {
    GWindow w;
    subdivideCanvas(w, 0, 0, w.getWidth(), w.getHeight());

    return 0;
}
