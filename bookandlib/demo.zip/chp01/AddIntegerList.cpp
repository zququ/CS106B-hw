/**
 * @file AddIntegerList.cpp
 * @author xuehao (xuehao0618@outlook.com)
 * @brief This program adds a list of integers. The end of the input is
 * indicated by entering a sentinel value, which is defined by setting the value
 * of the constant STNTINEL.
 * @version 0.1
 * @date 2021-12-01
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <iostream>

#include "console.h"

using namespace std;

/**
 * @brief SENTINEL
 * Defines the value used to terminate the input list.
 */

const int SENTINEL = 0;

int
main()
{
  cout << "This program adds a list of numbers." << endl;
  cout << "Use " << SENTINEL << " to signal the end." << endl;

  int total = 0;

  while (true) {
    int value;
    cout << " ? ";
    cin >> value;
    if (value == SENTINEL)
      break;
    total += value;
  }

  cout << "The total is " << total << endl;

  return 0;
}
