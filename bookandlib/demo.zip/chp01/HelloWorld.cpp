/**
 * @file HelloWorld.cpp
 * @author xuehao (xuehao0618@outlook.com)
 * @brief This file is adapted from K&C.
 * @version 0.1
 * @date 2021-12-01
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <iostream>

#include "console.h"

using namespace std;

int
main()
{
  cout << "Hello, World!" << endl;

  return 0;
}
