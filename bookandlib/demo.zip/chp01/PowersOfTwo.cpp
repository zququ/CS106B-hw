/**
 * @file PowersOfTwo.cpp
 * @author xuehao (xuehao0618@outlook.com)
 * @brief This program generates a list of the powers of 2 up to an exponent
 * limit entered by the user.
 * @version 0.1
 * @date 2021-12-01
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <iostream>

#include "console.h"

using namespace std;

int
raiseToPower(int n, int k);

int
main()
{
  int limit;

  cout << "This program lists powers of two." << endl;
  cout << "Enter exponent limit: ";
  cin >> limit;
  for (int i = 0; i <= limit; i++) {
    cout << "2 to the " << i << " = " << raiseToPower(2, i) << endl;
  }

  return 0;
}

/**
 * @brief raiseToPower
 *
 * Usage: int p = raiseToPower(n, k);
 * ----------------------------------
 * Return the integer n raised to the kth power.
 *
 * @param n
 * @param k
 * @return int
 */

int
raiseToPower(int n, int k)
{
  int result = 1;
  for (size_t i = 0; i < k; i++) {
    result *= n;
  }
  return result;
}
