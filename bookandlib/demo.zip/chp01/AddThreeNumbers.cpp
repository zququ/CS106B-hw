/**
 * @file AddThreeNumbers.cpp
 * @author xuehao (xuehao0618@outlook.com)
 * @brief This program adds 3 floating-poin numbers and prints their sum.
 * @version 0.1
 * @date 2021-12-01
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <iostream>

#include "console.h"

using namespace std;

int
main()
{
  double n1, n2, n3;

  cout << "This program adds 3 numbers." << endl;
  cout << "1st number: ";
  cin >> n1;
  cout << "2nd number: ";
  cin >> n2;
  cout << "3rd number: ";
  cin >> n3;

  double sum = n1 + n2 + n3;
  cout << "This sum is " << sum << endl;

  return 0;
}
