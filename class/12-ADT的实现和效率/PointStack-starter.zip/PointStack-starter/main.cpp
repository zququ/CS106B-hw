#include "testing/SimpleTest.h"

int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }

    return 0;
}
