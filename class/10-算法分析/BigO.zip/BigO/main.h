#pragma once

#include "vector.h"

void sort(Vector<int> &vec);
int maxOf(Vector<int> elems);
int maxOfDevide(Vector<int> elems);
int maxOfRef(Vector<int> elems);
