#pragma once

#include "listnode.h"

void runSort(ListNode*& front);
void quickSort(ListNode*& front);
