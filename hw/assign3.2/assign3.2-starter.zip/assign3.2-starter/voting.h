#pragma once
#include "vector.h"

Vector<int> computePowerIndexes(Vector<int>& blocks);
