
MENU_OPTION("Reset Sierpinski", makeInteractiveSierpinskiGUI)

WINDOW_TITLE("Recursion Graphics")
